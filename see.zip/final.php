<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=Anaheim|Dancing+Script|Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="gb.css">

    <title>iPredict!</title>
  </head>
  <body>
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1>iPredict</h1>
        <div class="bubu">
        <div class="bu btn-group mr-2" role="group" aria-label="Second group">
            <a href="r.html">
          <button type="button" class="btn btn-secondary" >Register</button>
            </a>
            <a href="test54.php">
          <button type="button" class="btn btn-secondary">Login</button>
            </a>
            <a href="lit.php">
          <button type="button" class="btn btn-secondary">Prediction</button>
        </a>
            <a href="#about">
          <button type="button" class="btn btn-secondary" >About</button>
            </a>
           
        </div>
        </div>
      </div>
    </div>
    <div class="container" >
        <div class="stats" style="float: left ;">
            <h2 >Statistics Of Diseases</h2>
            

 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Malaria',     11],
          ['Dengu',      2],
          ['Flue',  2],
          ['Pox', 2],
          ['Sleep',    7]
        ]);

        var options = {
          title: 'Current Month',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <div id="piechart_3d" style="width:500px ; height: 500px;"></div>
</div>
    <div class="predict"  >
      <b><h2>Overview</h2></b>
      <p>In this month, Malaria outbreak is predicted. 127 cases have been registered with symptoms of malaria</p>
      <br>
      <p>
        <h5>Symptoms</h5><br>
        Symptoms are chills, fever and sweating, usually occurring a few weeks after being bitten.
      </p>
      <p>
        <h5>Precautions</h5><br>
        Awareness of risk, bite prevention by mosquito nets, have anti-malarial tablets to prevent.
      </p>
    </div>
    
  </div>
  </div>

      <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>

