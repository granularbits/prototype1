<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=Anaheim|Dancing+Script|Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="gb.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Hello, world!</title>
  </head>
  <body>
  	 <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1>iPredict</h1>
        <div class="bubu">
        <div class="bu btn-group mr-2" role="group" aria-label="Second group">
            <a href="final.php">
          <button type="button" class="btn btn-secondary" >Home</button>
            </a>
                     <a href="r.html">
          <button type="button" class="btn btn-secondary">Register</button>
        </a>
            <a href="test54.php">
          <button type="button" class="btn btn-secondary">Login</button>
            </a>
        
            <a href="#about">
          <button type="button" class="btn btn-secondary" >About</button>
        </div>
        </div>
      </div>
    </div>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img class="d-block w-100" src="m.png" alt="First slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="n.png" alt="Second slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="p.png" alt="Third slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="mnp18.png" alt="Third slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="mnp17.png" alt="Third slide">
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>

  </body>
</html>



