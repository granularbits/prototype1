<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Add Data</title>
<link rel="stylesheet" href="test54.css">
  <link href="https://fonts.googleapis.com/css?family=Anaheim|Dancing+Script|Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="gb.css">

    <title>Hello, world!</title>
  </head>
  <body style="background-color:#bdc3c7">
    <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1>iPredict</h1>
        <div class="bubu">
        <div class="bu btn-group mr-2" role="group" aria-label="Second group">
            <a href="r.html">
          <button type="button" class="btn btn-secondary" >Register</button>
            </a>
            <a href="test54.php">
          <button type="button" class="btn btn-secondary">Login</button>
            </a>
          <button type="button" class="btn btn-secondary">About</button>
        </div>
        </div>
      </div>
    </div>


	<div id="main-wrapper">
	<center><h2>Add Data</h2></center>
		<form action="test54input.php" method="post">		
			<div class="inner_container">

			<label><b>Month</b></label>	
				<input style="margin-bottom: 10px;" name="month" placeholder="yyyy-mm" type="month"><br>
			<label><b>Disease</b></label>
				<input style="margin-bottom: 10px;" type="text" placeholder="Enter Disease" name="disease" required><br>
			<label><b>District</b></label>
				<select style="width: 430px;margin: 0 0 10px 0;padding: 10px;border: 1px solid #ccc;" type="text" placeholder="Select District" name="district" required>
					<option name="Ahmednagar">Bengaluru</option>
					<option name="Jalgaon">Udipi</option>
					<option name="Pune">Mangalore</option>
					<option name="Akola">Hubli</option>
					<option name="Jalna">Belgavi</option>
					
				</select><br>
			<label><b>Patient Diagnosed</b></label>
				<input style="margin-bottom: 10px;" type="number" placeholder="Enter no. of people diagnosed" name="diagnosed" required><br>
			<label><b>Patient Died</b></label>
				<input style="margin-bottom: 10px;" type="number" placeholder="Enter no. of people died" name="died" required><br>
			

<button name="sign_in" class="sign_up_btn" type="submit" onclick="alert('Thank You')">Submit</button>
				
				<a href="final.php"><button type="button" class="back_btn">Back to home page</button></a>
			</div>
		</form>

		<?php
			if($_POST)
			{
				$con = mysqli_connect("localhost","root","");
				$db = mysqli_select_db($con,"fin");
				@$month=$_POST['month'];
				@$disease=$_POST['disease'];
				@$district=$_POST['district'];
				@$diagnosed=$_POST['diagnosed'];
				@$died=$_POST['died'];

					$query = "select diagnosed,died from inputdata where month='$month' && lower(disease)=lower('$disease') && district='$district'";

					$query_run = mysqli_query($con,$query);

					if($query_run->num_rows > 0){
						$uquery="update inputdata set diagnosed=diagnosed+'$diagnosed',died=died+'$died' where month='$month' && lower(disease)=lower('$disease') && district='$district'";
						if(mysqli_query($con,$uquery)){

							echo '<script type="text/javascript">alert("successful")</script>';
							header('Location: /test54input.php');

						}else{

							echo '<script type="text/javascript">alert("DB error")</script>';

						}				

					}else{
						$iquery="insert into inputdata (month,disease,district,diagnosed,died) values ('$month',lower('$disease'),'$district','$diagnosed','$died')";
						if(mysqli_query($con,$iquery)){

							echo '<script type="text/javascript">alert("successful")</script>';
							header('Location: /test54input.php');

						}else{

							echo '<script type="text/javascript">alert("DB error")</script>';

						}	

					}

				
				
			}
			
		?>
	</div>
</body>
</html>