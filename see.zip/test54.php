<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Sign In Page</title>
<link rel="stylesheet" href="test54.css">
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=Anaheim|Dancing+Script|Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="gb.css">
</head>
<body style="background-color:#bdc3c7">
  <div class="jumbotron jumbotron-fluid">
      <div class="container">
        <h1>iPredict</h1>
        <div class="bubu">
        <div class="bu btn-group mr-2" role="group" aria-label="Second group">
              <a href="final.php">
          <button type="button" class="btn btn-secondary" >Home</button>
            </a>
            <a href="r.html">
          <button type="button" class="btn btn-secondary">Register</button>
            </a>
            <a href="lit.php">
          <button type="button" class="btn btn-secondary">Prediction</button>
        </a>
            <a href="#about">
          <button type="button" class="btn btn-secondary" >About</button>
            </a>
           
        </div>
        </div>
      </div>
    </div>


	<div id="main-wrapper">
	<center><h2>Sign in</h2></center>
		<form action="test54.php" method="post">
			<div class="imgcontainer">
				<img src="avatar.png" alt="Avatar" class="avatar">
			</div>			
			<div class="inner_container">
			<label><b>Registration Id</b></label>
				<input type="text" placeholder="Enter Id" name="id" required><br>
			<label><b>Password</b></label>
				<input type="password" placeholder="Enter password" name="password" required><br>
			

		


<button name="sign_in" class="sign_up_btn" type="submit">Sign In</button>
				
				<a href="final.php"><button type="button" class="back_btn">Back to home page</button></a>
			</div>
		</form>

		<?php
			if($_POST)
			{
				$con = mysqli_connect("localhost","root","");
				$db = mysqli_select_db($con,"fin");
				@$id=$_POST['id'];
				@$password=$_POST['password'];
				
				
					$query = "select password from user where id='$id'";
					//echo $query;
				$query_run = mysqli_query($con,$query);
				//echo mysql_num_rows($query_run);
				if($query_run->num_rows > 0)
					{
						// output data of each row
					    while($row = $query_run->fetch_assoc()) {
					        if ($row["password"]==$password) {
					        	header('Location: /test54input.php');
					        }
					    }
					}
					else
					{
						echo '<script type="text/javascript">alert("DB error")</script>';
					}
				
				
				
			}
			
		?>
	</div>
</body>
</html>